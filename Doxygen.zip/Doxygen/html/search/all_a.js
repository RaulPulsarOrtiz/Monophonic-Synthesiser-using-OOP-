var searchData=
[
  ['nextsample_0',['nextSample',['../class_oscillator.html#a38ec8a0da1aa8357eda0380bdd4f2243',1,'Oscillator']]],
  ['numfileitems_1',['NumFileItems',['../class_main_component.html#a7d3719f13c4b2955bbb83c9b4aa89dc3a541ac6e85752b3df6d02f73c184337d4',1,'MainComponent']]],
  ['nummenus_2',['NumMenus',['../class_main_component.html#a9f799d008898779d016029b39c6b3c4dafe1db9823261161ddb48cee8016e224d',1,'MainComponent']]]
];
