var searchData=
[
  ['renderwaveshape_0',['renderWaveShape',['../class_oscillator.html#aac3ef415f745ea0c4ce3c3591f52683e',1,'Oscillator::renderWaveShape()'],['../class_sawtooth.html#a3e66518a0f26718aabe9e45ec36bac78',1,'Sawtooth::renderWaveShape()'],['../class_sin_oscillator.html#a88bae8d609c27714b0fb1078b4e559cc',1,'SinOscillator::renderWaveShape()'],['../class_square_oscillator.html#a4da81b5d5b7eb6f410ab343ad9cb2208',1,'SquareOscillator::renderWaveShape()'],['../class_triangle.html#a32bd355bbefbe5bea9a87cd8b8a3c6c1',1,'Triangle::renderWaveShape()']]],
  ['resized_1',['resized',['../class_main_component.html#a339148bc43089300e10d5883a0a80726',1,'MainComponent::resized()'],['../class_my_synth_gui.html#a7876caf19511888a97a28df68fb787a6',1,'MySynthGui::resized()'],['../class_tremolo_gui.html#a77b48c53a4e9f0582264a6c01cf58e66',1,'TremoloGui::resized()'],['../class_vibrato_gui.html#a6bbb5cc9d31dee1191a7bd316ee2b585',1,'VibratoGui::resized()']]]
];
