var searchData=
[
  ['filemenuitems_0',['FileMenuItems',['../class_main_component.html#a7d3719f13c4b2955bbb83c9b4aa89dc3',1,'MainComponent']]]
];
