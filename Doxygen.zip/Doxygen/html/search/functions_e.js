var searchData=
[
  ['vibrato_0',['Vibrato',['../class_vibrato.html#a2ffc6869dcc9919bbcc279da3bd52e39',1,'Vibrato']]],
  ['vibratogui_1',['VibratoGui',['../class_vibrato_gui.html#a968b40015fded21a6bdd702bf81b86aa',1,'VibratoGui']]]
];
