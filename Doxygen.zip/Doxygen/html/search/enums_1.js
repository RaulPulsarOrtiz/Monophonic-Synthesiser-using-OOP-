var searchData=
[
  ['menus_0',['Menus',['../class_main_component.html#a9f799d008898779d016029b39c6b3c4d',1,'MainComponent']]]
];
