var searchData=
[
  ['buttonclicked_0',['buttonClicked',['../class_my_synth_gui.html#a271d0d591f4725957081c307c2335220',1,'MySynthGui::buttonClicked()'],['../class_tremolo_gui.html#a4aa6c84c670415339dc5906a93a71042',1,'TremoloGui::buttonClicked()'],['../class_vibrato_gui.html#a180fd401299953f05bf37ea56a86be9e',1,'VibratoGui::buttonClicked()']]]
];
