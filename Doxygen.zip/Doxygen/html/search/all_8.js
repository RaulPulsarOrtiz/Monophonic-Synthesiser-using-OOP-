var searchData=
[
  ['juceaudioapplication_0',['JuceAudioApplication',['../class_juce_audio_application.html',1,'JuceAudioApplication'],['../class_juce_audio_application.html#a170baebe4b4fc3e669f673dd6a413d2b',1,'JuceAudioApplication::JuceAudioApplication()']]]
];
