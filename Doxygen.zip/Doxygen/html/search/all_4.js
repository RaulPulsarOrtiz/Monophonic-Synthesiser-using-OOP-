var searchData=
[
  ['filemenu_0',['FileMenu',['../class_main_component.html#a9f799d008898779d016029b39c6b3c4da22a7ea69f152749a9bbca435dfeec258',1,'MainComponent']]],
  ['filemenuitems_1',['FileMenuItems',['../class_main_component.html#a7d3719f13c4b2955bbb83c9b4aa89dc3',1,'MainComponent']]]
];
