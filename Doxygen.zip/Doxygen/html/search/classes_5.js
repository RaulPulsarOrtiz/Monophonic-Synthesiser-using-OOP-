var searchData=
[
  ['tremolo_0',['Tremolo',['../class_tremolo.html',1,'']]],
  ['tremologui_1',['TremoloGui',['../class_tremolo_gui.html',1,'']]],
  ['triangle_2',['Triangle',['../class_triangle.html',1,'']]]
];
