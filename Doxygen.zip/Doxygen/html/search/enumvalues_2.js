var searchData=
[
  ['numfileitems_0',['NumFileItems',['../class_main_component.html#a7d3719f13c4b2955bbb83c9b4aa89dc3a541ac6e85752b3df6d02f73c184337d4',1,'MainComponent']]],
  ['nummenus_1',['NumMenus',['../class_main_component.html#a9f799d008898779d016029b39c6b3c4dafe1db9823261161ddb48cee8016e224d',1,'MainComponent']]]
];
