var searchData=
[
  ['audioprefs_0',['AudioPrefs',['../class_main_component.html#a7d3719f13c4b2955bbb83c9b4aa89dc3a8e5a45f7ec0fcd05fe3c8abb90b1eaf2',1,'MainComponent']]]
];
