var searchData=
[
  ['getapplicationname_0',['getApplicationName',['../class_juce_audio_application.html#a6ca0f8abadc4565c7ca579d006f9a962',1,'JuceAudioApplication']]],
  ['getapplicationversion_1',['getApplicationVersion',['../class_juce_audio_application.html#a229c8f4679adbe00013e37b80b5f8e7b',1,'JuceAudioApplication']]],
  ['getaudiodevicemanager_2',['getAudioDeviceManager',['../class_audio.html#a90ae49dcc4b23441f3d95595ecb605ad',1,'Audio']]],
  ['getfrequency_3',['getFrequency',['../class_oscillator.html#a2b9fbc7ace34e7b193bce2610b87ba3e',1,'Oscillator']]],
  ['getlfonextsample_4',['getLFONextSample',['../class_tremolo.html#aa75a66be14addf77d4284010e0e950f7',1,'Tremolo']]],
  ['getmenubarnames_5',['getMenuBarNames',['../class_main_component.html#abb3226917f6b1ec0fe420e9e837e0ab7',1,'MainComponent']]],
  ['getmenuforindex_6',['getMenuForIndex',['../class_main_component.html#aab76e7b9a141591f2c5dbdf94b0d7124',1,'MainComponent']]],
  ['getoscnextsample_7',['getOscNextSample',['../class_my_synth.html#ac0d6ec05afb9f109ecb315d16d9b22e9',1,'MySynth']]],
  ['getosctype_8',['getOscType',['../class_my_synth.html#a26c80aaa86a5901ebd1c90d5c43dce28',1,'MySynth']]],
  ['getsynth_9',['getSynth',['../class_audio.html#a0abbf93949a5016af27568563748f6f5',1,'Audio']]],
  ['gettremolo_10',['getTremolo',['../class_audio.html#aafdb6fde0a187b17c1b744f6939678d3',1,'Audio']]],
  ['getvibrato_11',['getVibrato',['../class_audio.html#a1ca8781366f3ac65e9a9f2989d1cfc12',1,'Audio']]],
  ['getvibratonextsample_12',['getVibratoNextSample',['../class_vibrato.html#a86411bbd3eec238cd9d1d8485b5cfa86',1,'Vibrato']]],
  ['givefrequency_13',['giveFrequency',['../class_my_synth.html#a4f23fb1eaf0eaae87f104c3bda77a3a8',1,'MySynth']]]
];
