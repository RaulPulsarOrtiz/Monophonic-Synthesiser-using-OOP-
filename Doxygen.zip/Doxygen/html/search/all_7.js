var searchData=
[
  ['initialise_0',['initialise',['../class_juce_audio_application.html#a7d33ebb76d7c205b8ac5c0735dbefe49',1,'JuceAudioApplication']]]
];
