var searchData=
[
  ['juceaudioapplication_0',['JuceAudioApplication',['../class_juce_audio_application.html',1,'']]]
];
