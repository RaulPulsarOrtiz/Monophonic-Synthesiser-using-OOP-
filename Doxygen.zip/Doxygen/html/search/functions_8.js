var searchData=
[
  ['nextsample_0',['nextSample',['../class_oscillator.html#a38ec8a0da1aa8357eda0380bdd4f2243',1,'Oscillator']]]
];
