var indexSectionsWithContent =
{
  0: "_abcfghijmnoprstv~",
  1: "ajmostv",
  2: "amostv",
  3: "abcghijmnoprstv~",
  4: "fm",
  5: "afn",
  6: "_"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "enumvalues",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Enumerations",
  5: "Enumerator",
  6: "Macros"
};

