var searchData=
[
  ['closebuttonpressed_0',['closeButtonPressed',['../class_juce_audio_application_1_1_main_window.html#a0fb285b57f6d3f7ec569bb3611e3e76d',1,'JuceAudioApplication::MainWindow']]],
  ['comboboxchanged_1',['comboBoxChanged',['../class_my_synth_gui.html#a997d5980e39dd4a0ff57caf682201225',1,'MySynthGui']]]
];
