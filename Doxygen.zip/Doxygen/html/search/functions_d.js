var searchData=
[
  ['tremolo_0',['Tremolo',['../class_tremolo.html#a4a35c188e9fc1311af22bb9c53f6c7f2',1,'Tremolo']]],
  ['tremologui_1',['TremoloGui',['../class_tremolo_gui.html#a1b84e2e2b83833f67f900ae87717104b',1,'TremoloGui']]],
  ['triangle_2',['Triangle',['../class_triangle.html#aaefe4ed500c07918d30c6f0e286332c5',1,'Triangle']]]
];
